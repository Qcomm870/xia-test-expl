/* KaDOS UI-слой: canvas 320x240, консоль 80x25, ввод клавиатуры Nokia.
   Работает и на десктопе (браузер), и на KaiOS. */
(function () {
  'use strict';
  var canvas = document.getElementById('scr');
  var hud = document.getElementById('hud');
  var ctx = canvas.getContext('2d');
  var img = ctx.createImageData(320, 200);

  // VGA-палитра mode 13h (16 базовых цветов EGA — достаточно для демо)
  var PAL = [
    [0,0,0],[170,0,0],[0,170,0],[170,85,0],[0,0,170],[170,0,170],[0,170,170],[170,170,170],
    [85,85,85],[255,85,85],[85,255,85],[255,255,85],[85,85,255],[255,85,255],[85,255,255],[255,255,255]
  ];

  var consoleText = '';
  var mode = 'text';            // 'text' | 'vga'
  var BUDGET = 3000;            // инструкций на кадр (~адаптивно ниже)
  var programName = '';
  var loadError = '';
  var filePanel = document.getElementById('file-panel');
  var fileList = document.getElementById('file-list');
  var fileSelected = -1;
  var fileItems = [];
  var fileButton = null;
  var editButton = document.getElementById('edit-text');
  var editorPanel = document.getElementById('editor-panel');
  var editorText = document.getElementById('editor-textarea');
  var editorT9Keys = Array.prototype.slice.call(document.querySelectorAll('.t9-key'));
  var editorState = { activeKey: null, step: 0, selectedIndex: 0 };
  var T9_MAP = {
    '1': '.,!?1',
    '2': 'abc2',
    '3': 'def3',
    '4': 'ghi4',
    '5': 'jkl5',
    '6': 'mno6',
    '7': 'pqrs7',
    '8': 'tuv8',
    '9': 'wxyz9'
  };

  function insertEditorChar(ch) {
    if (!editorText) return;
    var start = editorText.selectionStart || 0;
    var end = editorText.selectionEnd || start;
    var value = editorText.value;
    editorText.value = value.slice(0, start) + ch + value.slice(end);
    var pos = start + ch.length;
    editorText.selectionStart = pos;
    editorText.selectionEnd = pos;
    editorText.focus();
  }

  function backspaceEditor() {
    if (!editorText) return;
    var start = editorText.selectionStart || 0;
    var end = editorText.selectionEnd || start;
    if (start === end && start > 0) {
      editorText.value = editorText.value.slice(0, start - 1) + editorText.value.slice(end);
      editorText.selectionStart = start - 1;
      editorText.selectionEnd = start - 1;
    } else {
      editorText.value = editorText.value.slice(0, start) + editorText.value.slice(end);
      editorText.selectionStart = start;
      editorText.selectionEnd = start;
    }
  }

  function triggerEditorKey(key) {
    if (!T9_MAP[key]) return;
    var letters = T9_MAP[key];
    if (editorState.activeKey === key) {
      editorState.step = (editorState.step + 1) % letters.length;
    } else {
      editorState.activeKey = key;
      editorState.step = 0;
    }
    var ch = letters.charAt(editorState.step);
    insertEditorChar(ch);
    updateEditorSelection();
  }

  function updateEditorSelection() {
    if (!editorT9Keys || !editorT9Keys.length) return;
    editorT9Keys.forEach(function (button) {
      var same = button.dataset.key === String(editorState.activeKey || '');
      button.classList.toggle('selected', same);
    });
  }

  function openEditorPanel() {
    if (filePanel) filePanel.classList.add('hidden');
    if (editorPanel) editorPanel.classList.remove('hidden');
    if (editorText) editorText.focus();
    editorState.selectedIndex = 0;
    updateEditorSelection();
  }

  function closeEditorPanel() {
    if (editorPanel) editorPanel.classList.add('hidden');
  }

  function saveCurrentEditor() {
    if (!editorText) return;
    loadError = 'Заметка сохранена: ' + String(editorText.value || '').slice(0, 24) || 'пусто';
    closeEditorPanel();
  }

  function drawText() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, 320, 240);
    ctx.fillStyle = '#0f0'; ctx.font = '10px monospace';
    var lines = consoleText.split('\n');
    var start = Math.max(0, lines.length - 22);
    for (var i = start; i < lines.length; i++) {
      ctx.fillText(lines[i].slice(0, 42), 4, 12 + (i - start) * 10);
    }
  }

  function drawVga() {
    var buf = window.KaDOS.vgaBuffer();
    var d = img.data;
    for (var i = 0; i < 320 * 200; i++) {
      var c = buf[i] & 15, p = PAL[c];
      var o = i * 4;
      d[o] = p[0]; d[o+1] = p[1]; d[o+2] = p[2]; d[o+3] = 255;
    }
    ctx.putImageData(img, 0, 20);   // центровка 200->240
  }

  function loop() {
    if (!window.KaDOS) { setTimeout(loop, 100); return; }
    var out = KaDOS.runSlice(BUDGET);
    var s = KaDOS.getConsole();
    if (s) { consoleText += s; mode = 'text'; }
    if (KaDOS.vgaDirtyConsume()) mode = 'vga';
    if (mode === 'vga') drawVga(); else drawText();
    if (loadError) {
      hud.textContent = loadError;
    } else if (!out.running) {
      hud.textContent = (programName ? programName + ' | ' : '') + 'HALT: ' + out.halted + ' (шагов: ' + out.steps + ')';
    } else {
      hud.textContent = programName + ' | running | IP=' + KaDOS.regs.ip.toString(16);
    }
    setTimeout(loop, 16);
  }

  function normalizeKey(e) {
    if (!e || !e.key) return null;
    if (window.KaLoader && typeof window.KaLoader.normalizeDeviceKey === 'function') {
      return window.KaLoader.normalizeDeviceKey(e.key);
    }
    return e.key;
  }

  // Клавиатура: KaiOS/D-pad / desktop; центр и стрелки должны работать на телефоне.
  document.addEventListener('keydown', function (e) {
    var key = normalizeKey(e);

    if (editorPanel && !editorPanel.classList.contains('hidden')) {
      if (key === 'ArrowUp' || key === 'ArrowLeft') {
        editorState.selectedIndex = (editorState.selectedIndex <= 0) ? editorT9Keys.length - 1 : editorState.selectedIndex - 1;
        updateEditorSelection();
        e.preventDefault();
        return;
      }
      if (key === 'ArrowDown' || key === 'ArrowRight') {
        editorState.selectedIndex = (editorState.selectedIndex + 1) % editorT9Keys.length;
        updateEditorSelection();
        e.preventDefault();
        return;
      }
      if (key === 'Enter' || key === 'Numpad5' || key === 'Spacebar') {
        var activeKey = editorT9Keys[editorState.selectedIndex];
        if (activeKey) {
          triggerEditorKey(activeKey.dataset.key);
        } else {
          insertEditorChar(' ');
        }
        e.preventDefault();
        return;
      }
      if (key === 'SoftLeft' || key === 'Escape') {
        closeEditorPanel();
        e.preventDefault();
        return;
      }
      if (key === 'SoftRight') {
        closeEditorPanel();
        e.preventDefault();
        return;
      }
      if (key === 'Backspace') {
        backspaceEditor();
        e.preventDefault();
        return;
      }
      if (/^[0-9]$/.test(String(key))) {
        triggerEditorKey(String(key));
        e.preventDefault();
        return;
      }
      if (key && key.length === 1) {
        insertEditorChar(key);
        e.preventDefault();
        return;
      }
    }

    if (filePanel && !filePanel.classList.contains('hidden')) {
      if (key === 'ArrowUp') {
        if (fileItems.length) {
          fileSelected = (fileSelected <= 0) ? fileItems.length - 1 : fileSelected - 1;
          renderFilePanel();
        }
        e.preventDefault();
        return;
      }
      if (key === 'ArrowDown') {
        if (fileItems.length) {
          fileSelected = (fileSelected >= fileItems.length - 1) ? 0 : fileSelected + 1;
          renderFilePanel();
        }
        e.preventDefault();
        return;
      }
      if (key === 'SoftLeft' || key === 'Enter') {
        chooseSelectedFile();
        e.preventDefault();
        return;
      }
      if (key === 'SoftRight') {
        fileButton && fileButton.click();
        e.preventDefault();
        return;
      }
      if (key === 'Escape' || key === 'Backspace') {
        closeFilePanel();
        e.preventDefault();
        return;
      }
    }

    if (!window.KaDOS) return;
    if (e.target && /^(INPUT|SELECT|BUTTON|TEXTAREA)$/.test(e.target.tagName)) return;

    var map = { Enter: 13, Backspace: 8, Escape: 27 };
    if (map[key] !== undefined) { KaDOS.pressKey(map[key]); e.preventDefault(); return; }
    if (key && key.length === 1) KaDOS.pressKey(key.toUpperCase().charCodeAt(0));

    var arrows = { ArrowUp: 0x4800, ArrowDown: 0x5000, ArrowLeft: 0x4B00, ArrowRight: 0x4D00 };
    if (arrows[key]) KaDOS.pressKey(arrows[key]);
  });

  function loadProgram(bytes, name) {
    try {
      KaDOS.loadCom(bytes);
      consoleText = '';
      mode = 'text';
      programName = name;
      loadError = '';
    } catch (e) {
      loadError = e.message;
    }
  }

  function renderFilePanel() {
    if (!fileList) return;
    fileList.innerHTML = '';
    fileItems.forEach(function (item, index) {
      var li = document.createElement('li');
      li.textContent = item.name;
      if (index === fileSelected) li.className = 'selected';
      li.addEventListener('click', function () {
        fileSelected = index;
        renderFilePanel();
      });
      fileList.appendChild(li);
    });
    if (!fileItems.length) {
      var empty = document.createElement('li');
      empty.textContent = 'Файлы не найдены';
      fileList.appendChild(empty);
    }
  }

  function closeFilePanel() {
    if (filePanel) filePanel.classList.add('hidden');
  }

  function openFilePanel() {
    if (!window.KaLoader || !window.KaLoader.listSdFiles) {
      return;
    }
    window.KaLoader.listSdFiles().then(function (items) {
      fileItems = items;
      fileSelected = items.length ? 0 : -1;
      renderFilePanel();
      if (filePanel) filePanel.classList.remove('hidden');
      if (!items.length) {
        loadError = 'На SD-карте не найдено файлов .COM/.BIN';
      }
    }, function () {
      loadError = 'Не удалось получить список файлов.';
    });
  }

  function chooseSelectedFile() {
    if (!fileItems.length || fileSelected < 0) {
      loadError = 'Файл не выбран.';
      return;
    }
    var item = fileItems[fileSelected];
    try {
      window.KaLoader.validateProgramFile(item.file);
    } catch (e) {
      loadError = e.message;
      closeFilePanel();
      return;
    }
    window.KaLoader.readFile(item.file).then(function (bytes) {
      loadProgram(bytes, item.name);
      closeFilePanel();
    }, function () {
      loadError = 'Не удалось прочитать файл.';
      closeFilePanel();
    });
  }

  function initializeControls() {
    var select = document.getElementById('demo-select');
    var runButton = document.getElementById('run-demo');
    var fileInput = document.getElementById('file-input');
    fileButton = document.getElementById('open-file');
    editButton = document.getElementById('edit-text');
    var softLeft = document.getElementById('soft-left');
    var softRight = document.getElementById('soft-right');
    var editorClose = document.getElementById('editor-close');
    var editorSave = document.getElementById('editor-save');
    var editorExit = document.getElementById('editor-exit');
    var editorSpace = document.getElementById('editor-space');
    var editorBackspace = document.getElementById('editor-backspace');
    editorT9Keys = Array.prototype.slice.call(document.querySelectorAll('.t9-key'));

    function bindPointerAction(el, fn) {
      if (!el) return;
      el.addEventListener('pointerdown', function (event) {
        event.preventDefault();
        fn(event);
      });
      el.addEventListener('click', function (event) {
        event.preventDefault();
        fn(event);
      });
    }

    window.KaLoader.DEMOS.forEach(function (demo, index) {
      var option = document.createElement('option');
      option.value = String(index);
      option.textContent = demo.name;
      select.appendChild(option);
    });

    bindPointerAction(runButton, function () {
      var demo = window.KaLoader.DEMOS[Number(select.value)];
      if (demo) loadProgram(demo.bytes, demo.name);
    });

    bindPointerAction(editButton, function () {
      openEditorPanel();
    });

    bindPointerAction(fileButton, function () {
      if (window.navigator && typeof navigator.getDeviceStorage === 'function') {
        openFilePanel();
      } else {
        fileInput.click();
      }
    });

    bindPointerAction(editorClose, function () {
      closeEditorPanel();
    });

    bindPointerAction(editorSave, function () {
      saveCurrentEditor();
    });

    bindPointerAction(editorExit, function () {
      closeEditorPanel();
    });

    bindPointerAction(editorSpace, function () {
      insertEditorChar(' ');
    });

    bindPointerAction(editorBackspace, function () {
      backspaceEditor();
    });

    editorT9Keys.forEach(function (button) {
      bindPointerAction(button, function () {
        triggerEditorKey(button.dataset.key);
      });
    });

    bindPointerAction(softLeft, function () {
      if (filePanel && !filePanel.classList.contains('hidden')) {
        chooseSelectedFile();
        return;
      }
      var demo = window.KaLoader.DEMOS[Number(select.value)];
      if (demo) loadProgram(demo.bytes, demo.name);
    });

    bindPointerAction(softRight, function () {
      if (filePanel && !filePanel.classList.contains('hidden')) {
        chooseSelectedFile();
        return;
      }
      fileButton && fileButton.click();
    });

    fileInput.addEventListener('change', function () {
      var file = fileInput.files && fileInput.files[0];
      if (!file) return;
      try {
        window.KaLoader.validateProgramFile(file);
      } catch (e) {
        loadError = e.message;
        fileInput.value = '';
        return;
      }
      window.KaLoader.readFile(file).then(function (bytes) {
        loadProgram(bytes, file.name);
      }, function () {
        loadError = 'Не удалось прочитать файл.';
      });
      fileInput.value = '';
    });

    closeFilePanel();
    loadProgram(window.KaLoader.DEMOS[0].bytes, window.KaLoader.DEMOS[0].name);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initializeControls(); loop(); });
  } else { initializeControls(); loop(); }
})();
