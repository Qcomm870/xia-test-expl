/* KaDOS UI-слой: canvas 320x240, консоль 80x25, ввод клавиатуры Nokia.
   Работает и на десктопе (браузер), и на KaiOS. */
(function () {
  'use strict';
  var canvas = document.getElementById('scr');
  var hud = document.getElementById('hud');
  var ctx = canvas.getContext('2d');
  var img = ctx.createImageData(320, 200);

  // VGA-палитра mode 13h (16 базовых цветов EGA — достаточно для демо)
  var PAL = [
    [0,0,0],[170,0,0],[0,170,0],[170,85,0],[0,0,170],[170,0,170],[0,170,170],[170,170,170],
    [85,85,85],[255,85,85],[85,255,85],[255,255,85],[85,85,255],[255,85,255],[85,255,255],[255,255,255]
  ];

  var consoleText = '';
  var mode = 'text';            // 'text' | 'vga'
  var BUDGET = 3000;            // инструкций на кадр (~адаптивно ниже)
  var programName = '';
  var loadError = '';

  function drawText() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, 320, 240);
    ctx.fillStyle = '#0f0'; ctx.font = '10px monospace';
    var lines = consoleText.split('\n');
    var start = Math.max(0, lines.length - 22);
    for (var i = start; i < lines.length; i++) {
      ctx.fillText(lines[i].slice(0, 42), 4, 12 + (i - start) * 10);
    }
  }

  function drawVga() {
    var buf = window.KaDOS.vgaBuffer();
    var d = img.data;
    for (var i = 0; i < 320 * 200; i++) {
      var c = buf[i] & 15, p = PAL[c];
      var o = i * 4;
      d[o] = p[0]; d[o+1] = p[1]; d[o+2] = p[2]; d[o+3] = 255;
    }
    ctx.putImageData(img, 0, 20);   // центровка 200->240
  }

  function loop() {
    if (!window.KaDOS) { setTimeout(loop, 100); return; }
    var out = KaDOS.runSlice(BUDGET);
    var s = KaDOS.getConsole();
    if (s) { consoleText += s; mode = 'text'; }
    if (KaDOS.vgaDirtyConsume()) mode = 'vga';
    if (mode === 'vga') drawVga(); else drawText();
    if (loadError) {
      hud.textContent = loadError;
    } else if (!out.running) {
      hud.textContent = (programName ? programName + ' | ' : '') + 'HALT: ' + out.halted + ' (шагов: ' + out.steps + ')';
    } else {
      hud.textContent = programName + ' | running | IP=' + KaDOS.regs.ip.toString(16);
    }
    setTimeout(loop, 16);
  }

  // Клавиатура: Nokia T9 -> scancode-like коды; на десктопе обычные клавиши
  document.addEventListener('keydown', function (e) {
    if (!window.KaDOS) return;
    if (e.target && /^(INPUT|SELECT|BUTTON)$/.test(e.target.tagName)) return;
    var map = { Enter: 13, Backspace: 8, Escape: 27 };
    if (map[e.key] !== undefined) { KaDOS.pressKey(map[e.key]); e.preventDefault(); return; }
    if (e.key.length === 1) KaDOS.pressKey(e.key.toUpperCase().charCodeAt(0));
    // стрелки: BIOS-коды
    var arrows = { ArrowUp: 0x4800, ArrowDown: 0x5000, ArrowLeft: 0x4B00, ArrowRight: 0x4D00 };
    if (arrows[e.key]) KaDOS.pressKey(arrows[e.key]);
  });

  function loadProgram(bytes, name) {
    try {
      KaDOS.loadCom(bytes);
      consoleText = '';
      mode = 'text';
      programName = name;
      loadError = '';
    } catch (e) {
      loadError = e.message;
    }
  }

  function initializeControls() {
    var select = document.getElementById('demo-select');
    var runButton = document.getElementById('run-demo');
    var fileInput = document.getElementById('file-input');
    var fileButton = document.getElementById('open-file');

    window.KaLoader.DEMOS.forEach(function (demo, index) {
      var option = document.createElement('option');
      option.value = String(index);
      option.textContent = demo.name;
      select.appendChild(option);
    });

    runButton.addEventListener('click', function () {
      var demo = window.KaLoader.DEMOS[Number(select.value)];
      if (demo) loadProgram(demo.bytes, demo.name);
    });

    if (fileButton) {
      fileButton.addEventListener('click', function () {
        if (window.navigator && typeof navigator.getDeviceStorage === 'function') {
          window.KaLoader.chooseFileFromSd().then(function (item) {
            var file = item.file;
            try {
              window.KaLoader.validateProgramFile(file);
            } catch (e) {
              loadError = e.message;
              return;
            }
            window.KaLoader.readFile(file).then(function (bytes) {
              loadProgram(bytes, item.name);
            }, function () {
              loadError = 'Не удалось прочитать файл.';
            });
          }, function (err) {
            loadError = err && err.message ? err.message : 'Не удалось выбрать файл.';
          });
          return;
        }
        fileInput.click();
      });
    }

    fileInput.addEventListener('change', function () {
      var file = fileInput.files && fileInput.files[0];
      if (!file) return;
      try {
        window.KaLoader.validateProgramFile(file);
      } catch (e) {
        loadError = e.message;
        fileInput.value = '';
        return;
      }
      window.KaLoader.readFile(file).then(function (bytes) {
        loadProgram(bytes, file.name);
      }, function () {
        loadError = 'Не удалось прочитать файл.';
      });
      fileInput.value = '';
    });

    loadProgram(window.KaLoader.DEMOS[0].bytes, window.KaLoader.DEMOS[0].name);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initializeControls(); loop(); });
  } else { initializeControls(); loop(); }
})();
