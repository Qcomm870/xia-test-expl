/* KaDOS UI-слой: canvas 320x240, консоль 80x25, ввод клавиатуры Nokia.
   Работает и на десктопе (браузер), и на KaiOS. */
(function () {
  'use strict';
  var canvas = document.getElementById('scr');
  var hud = document.getElementById('hud');
  var ctx = canvas.getContext('2d');
  var img = ctx.createImageData(320, 200);

  // VGA-палитра mode 13h (16 базовых цветов EGA — достаточно для демо)
  var PAL = [
    [0,0,0],[170,0,0],[0,170,0],[170,85,0],[0,0,170],[170,0,170],[0,170,170],[170,170,170],
    [85,85,85],[255,85,85],[85,255,85],[255,255,85],[85,85,255],[255,85,255],[85,255,255],[255,255,255]
  ];

  var consoleText = '';
  var mode = 'text';            // 'text' | 'vga'
  var BUDGET = 3000;            // инструкций на кадр (~адаптивно ниже)
  var programName = '';
  var loadError = '';
  var filePanel = document.getElementById('file-panel');
  var fileList = document.getElementById('file-list');
  var fileSelected = -1;
  var fileItems = [];
  var fileButton = null;
  var editButton = document.getElementById('edit-text');
  var actionsButton = document.getElementById('open-actions');
  var editorPanel = document.getElementById('editor-panel');
  var editorText = document.getElementById('editor-textarea');
  var currentFilename = document.getElementById('filename-label');
  var editorFilename = document.getElementById('editor-filename');
  var currentFile = null;
  var saveFormat = '.txt';
  var fileFilterMode = 'all';

  function setCurrentFile(item, displayName) {
    currentFile = item || null;
    var name = displayName || (item && item.name) || 'Без имени';
    if (currentFilename) currentFilename.textContent = name;
    if (editorFilename) editorFilename.textContent = name;
  }

  function closePanels() {
    ['file-panel', 'editor-panel', 'actions-panel', 'save-as-panel', 'delete-panel'].forEach(function (id) {
      var panel = document.getElementById(id);
      if (panel) panel.classList.add('hidden');
    });
  }

  function showPanel(panel) {
    closePanels();
    if (panel) panel.classList.remove('hidden');
  }

  function showStatus(message) {
    loadError = message || '';
    if (hud) hud.textContent = loadError;
  }

  function formatSaveError(prefix, error) {
    var details = [];
    if (error && error.name) details.push(error.name);
    if (error && error.message && error.message !== error.name) details.push(error.message);
    if (!details.length && error) details.push(String(error));
    return prefix + (details.length ? ': ' + details.join(' - ') : '.');
  }

  function showSaveToast(message) {
    var toast = document.getElementById('save-status-panel');
    var label = document.getElementById('save-status-message');
    var button = document.getElementById('save-status-ok');
    if (label) label.textContent = message || 'Файл был сохранен';
    if (toast) {
      toast.classList.remove('hidden');
      showPanel(toast);
    }
    if (button) {
      setTimeout(function () {
        if (button) button.focus();
      }, 0);
    }
  }

  function closeSaveToast() {
    var toast = document.getElementById('save-status-panel');
    if (toast) toast.classList.add('hidden');
    closePanels();
    editButton && editButton.focus();
  }

  function openEditorPanel(text) {
    showPanel(editorPanel);
    if (typeof text === 'string') editorText.value = text;
    if (editorFilename) editorFilename.textContent = currentFile ? currentFile.name : 'Новая заметка.txt';
    if (editorText) editorText.focus();
  }

  function closeEditorPanel() {
    closePanels();
    editButton && editButton.focus();
  }

  function saveCurrentEditor() {
    if (!editorText) return;
    if (currentFile && /\.(com|bin)$/i.test(currentFile.name)) {
      loadError = 'Нельзя сохранять текст поверх бинарного файла.';
      return;
    }
    var targetStorage = currentFile && currentFile.storage ? currentFile.storage : window.KaLoader.preferredStorage();
    var targetPath = currentFile && currentFile.path ? currentFile.path : 'KaDOS/notes.txt';
    if (targetStorage && currentFile && currentFile.storage) {
      window.KaLoader.saveTextFile(targetStorage, targetPath, editorText.value, true).then(function () {
        window.KaLoader.saveNote(editorText.value, []).catch(function () {});
        showStatus('Файл был сохранен');
        showSaveToast('Файл был сохранен');
      }, function (error) {
        var message = formatSaveError('Не удалось сохранить файл', error);
        showStatus(message);
        showSaveToast(message);
      });
      return;
    }
    if (currentFile && !currentFile.storage) {
      beginSaveAs(false);
      return;
    }
    window.KaLoader.saveNote(editorText.value, targetStorage ? [targetStorage] : []).then(function (result) {
      if (result.storageSaved) {
        var name = result.path.split('/').pop();
        setCurrentFile({
          name: name,
          path: result.path,
          storageName: result.storageName,
          storage: targetStorage,
          file: { name: result.path, size: editorText.value.length }
        }, name);
        showStatus('Файл был сохранен');
        showSaveToast('Файл был сохранен');
      } else {
        var saveFailure = result.error
          ? 'Не удалось сохранить файл: ' + (result.error.message || result.error)
          : 'Хранилище недоступно. Черновик сохранен только в приложении; файл не создан.';
        showStatus(saveFailure);
        showSaveToast(saveFailure);
      }
    }, function (error) {
      var message = formatSaveError('Не удалось сохранить заметку', error);
      showStatus(message);
      showSaveToast(message);
    });
  }

  function beginSaveAs(createNewFile) {
    var nameInput = document.getElementById('saveas-name');
    var baseName = createNewFile ? 'note' : (currentFile && currentFile.name ? currentFile.name.replace(/\.[^.]*$/, '') : 'note');
    var confirmButton = document.getElementById('saveas-confirm');
    var formatButtons = document.querySelectorAll('#save-formats [data-format]');
    Array.prototype.forEach.call(formatButtons, function (button) {
      button.classList.toggle('selected', button.dataset.format === saveFormat);
    });
    if (nameInput) nameInput.value = baseName || 'note';
    if (confirmButton) confirmButton.textContent = createNewFile ? 'Создать файл' : 'Сохранить как';
    showPanel(document.getElementById('save-as-panel'));
    if (nameInput) nameInput.focus();
  }

  function saveAsEditorText() {
    var nameInput = document.getElementById('saveas-name');
    var baseName = String(nameInput && nameInput.value || '').trim().replace(/\.[^.]*$/, '').replace(/[\\/:*?"<>|]/g, '-');
    if (!baseName) {
      showStatus('Введите имя файла.');
      if (nameInput) nameInput.focus();
      return;
    }
    var storage = currentFile && currentFile.storage || window.KaLoader.preferredStorage();
    if (!storage) {
      var storageError = 'Нет доступного хранилища для сохранения.';
      showStatus(storageError);
      showSaveToast(storageError);
      return;
    }
    var currentPath = currentFile && currentFile.path ? currentFile.path : '';
    var relativePath = window.KaLoader.resolveSaveTargetPath
      ? window.KaLoader.resolveSaveTargetPath(currentPath, baseName + saveFormat)
      : (baseName + saveFormat);
    var sameCurrentPath = !!(currentFile && currentFile.storage === storage && currentFile.path &&
      window.KaLoader.resolveSaveTargetPath(currentFile.path, currentFile.name) === relativePath);
    var path = sameCurrentPath ? currentFile.path : relativePath;
    window.KaLoader.saveTextFile(storage, path, editorText.value, sameCurrentPath).then(function (saved) {
      setCurrentFile({
        name: baseName + saveFormat,
        path: saved.path,
        storageName: saved.storageName,
        storage: storage,
        file: { name: saved.path, size: editorText.value.length }
      }, baseName + saveFormat);
      window.KaLoader.saveNote(editorText.value, []).catch(function () {});
      showStatus('Файл был сохранен');
      showSaveToast('Файл был сохранен');
    }, function (error) {
      var message = formatSaveError('Не удалось сохранить файл как новый', error);
      showStatus(message);
      showSaveToast(message);
    });
  }

  function confirmDeleteCurrentFile() {
    if (!currentFile) {
      window.KaLoader.deleteSavedNote();
      editorText.value = '';
      loadError = 'Заметка удалена из памяти приложения.';
      setCurrentFile(null, 'Без имени');
      closePanels();
      fileButton && fileButton.focus();
      return;
    }
    if (!currentFile || !currentFile.storage) {
      loadError = 'Выбранный локальный файл нельзя удалить через KaiOS Device Storage.';
      closePanels();
      actionsButton && actionsButton.focus();
      return;
    }
    window.KaLoader.deleteFile(currentFile).then(function () {
      loadError = 'Файл удалён: ' + currentFile.path;
      setCurrentFile(null, 'Без имени');
      editorText.value = '';
      closePanels();
      fileButton && fileButton.focus();
    }, function (error) {
      loadError = 'Не удалось удалить файл: ' + (error.message || error);
      closePanels();
      actionsButton && actionsButton.focus();
    });
  }

  function beginDeleteCurrentFile() {
    var message = document.getElementById('delete-message');
    var confirmButton = document.getElementById('delete-confirm');
    if (message) {
      message.textContent = currentFile
        ? 'Удалить файл «' + (currentFile.name || currentFile.path) + '»?'
        : 'Удалить сохраненную заметку из памяти приложения?';
    }
    showPanel(document.getElementById('delete-panel'));
    if (confirmButton) confirmButton.focus();
  }

  function drawText() {
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, 320, 240);
    ctx.fillStyle = '#0f0'; ctx.font = '10px monospace';
    var lines = consoleText.split('\n');
    var start = Math.max(0, lines.length - 22);
    for (var i = start; i < lines.length; i++) {
      ctx.fillText(lines[i].slice(0, 42), 4, 12 + (i - start) * 10);
    }
  }

  function drawVga() {
    var buf = window.KaDOS.vgaBuffer();
    var d = img.data;
    for (var i = 0; i < 320 * 200; i++) {
      var c = buf[i] & 15, p = PAL[c];
      var o = i * 4;
      d[o] = p[0]; d[o+1] = p[1]; d[o+2] = p[2]; d[o+3] = 255;
    }
    ctx.putImageData(img, 0, 20);   // центровка 200->240
  }

  function loop() {
    if (!window.KaDOS) { setTimeout(loop, 100); return; }
    var out = KaDOS.runSlice(BUDGET);
    var s = KaDOS.getConsole();
    if (s) { consoleText += s; mode = 'text'; }
    if (KaDOS.vgaDirtyConsume()) mode = 'vga';
    if (mode === 'vga') drawVga(); else drawText();
    if (loadError) {
      hud.textContent = loadError;
    } else if (!out.running) {
      hud.textContent = (programName ? programName + ' | ' : '') + 'HALT: ' + out.halted + ' (шагов: ' + out.steps + ')';
    } else {
      hud.textContent = programName + ' | running | IP=' + KaDOS.regs.ip.toString(16);
    }
    setTimeout(loop, 16);
  }

  function normalizeKey(e) {
    if (!e) return null;
    if (window.KaLoader && typeof window.KaLoader.normalizeDeviceKey === 'function') {
      return window.KaLoader.normalizeDeviceKey(e);
    }
    return e.key || null;
  }

  function visiblePanel() {
    var panels = document.querySelectorAll('.panel:not(.hidden)');
    if (panels.length) return panels[panels.length - 1];
    return document.querySelector('.app-shell');
  }

  function fileListDirectionalKey(key) {
    var panel = visiblePanel();
    if (!panel || !panel.classList || !panel.classList.contains('panel')) return key;
    if (panel.id === 'save-as-panel') {
      if (document.activeElement.id === 'saveas-name' && (key === 'ArrowLeft' || key === 'ArrowRight')) return key;
      if (window.KaLoader && typeof window.KaLoader.normalizeSaveAsDirection === 'function') {
        return window.KaLoader.normalizeSaveAsDirection(key);
      }
    }
    if (window.KaLoader && typeof window.KaLoader.normalizeMenuDirection === 'function') {
      return window.KaLoader.normalizeMenuDirection(key);
    }
    return key;
  }

  function focusableItems() {
    var root = visiblePanel();
    if (!root) return [];
    var nodes = root.querySelectorAll('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), [tabindex="0"]');
    return Array.prototype.filter.call(nodes, function (node) {
      return node !== canvas && !node.hidden && node.getClientRects().length > 0;
    });
  }

  function moveFocus(direction) {
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].indexOf(direction) < 0) return;
    var items = focusableItems();
    if (!items.length) return;
    var current = document.activeElement;
    var currentIndex = items.indexOf(current);
    if (currentIndex < 0) {
      items[0].focus();
      return;
    }

    var from = current.getBoundingClientRect();
    var fromX = from.left + from.width / 2;
    var fromY = from.top + from.height / 2;
    var vertical = direction === 'ArrowUp' || direction === 'ArrowDown';
    var best = null;
    var bestScore = Infinity;
    items.forEach(function (item) {
      if (item === current) return;
      var rect = item.getBoundingClientRect();
      var x = rect.left + rect.width / 2;
      var y = rect.top + rect.height / 2;
      var primary = vertical
        ? (direction === 'ArrowDown' ? y - fromY : fromY - y)
        : (direction === 'ArrowRight' ? x - fromX : fromX - x);
      if (primary <= 0) return;
      var secondary = vertical ? Math.abs(x - fromX) : Math.abs(y - fromY);
      var score = primary + secondary * 2;
      if (score < bestScore) {
        best = item;
        bestScore = score;
      }
    });
    if (best) {
      best.focus();
      return;
    }

    var step = (direction === 'ArrowUp' || direction === 'ArrowLeft') ? -1 : 1;
    items[(currentIndex + step + items.length) % items.length].focus();
  }

  function moveSaveAsFocus(direction) {
    if (direction !== 'ArrowUp' && direction !== 'ArrowDown') return false;
    var panel = document.getElementById('save-as-panel');
    if (!panel || panel.classList.contains('hidden')) return false;
    var items = Array.prototype.slice.call(panel.querySelectorAll('#saveas-name, #save-formats [data-format], #saveas-confirm'));
    var currentIndex = items.indexOf(document.activeElement);
    if (currentIndex < 0) return false;
    var offset = direction === 'ArrowDown' ? 1 : -1;
    var nextIndex = currentIndex + offset;
    if (nextIndex >= 0 && nextIndex < items.length) items[nextIndex].focus();
    return true;
  }

  // Keep menu movement, text caret movement, and emulator controls separate.
  function closeToPreviousAction() {
    var panel = visiblePanel();
    if (panel && panel.classList.contains('panel')) {
      if (panel.id === 'save-status-panel') {
        closeSaveToast();
        return true;
      }
      if (panel.id === 'save-as-panel') {
        var saveAsActionsPanel = document.getElementById('actions-panel');
        showPanel(saveAsActionsPanel);
        var saveAsButton = document.getElementById('save-as-file');
        if (saveAsButton) saveAsButton.focus();
        return true;
      }
      closePanels();
      if (panel === filePanel) {
        editButton && editButton.focus();
      } else if (panel.id === 'actions-panel') {
        actionsButton && actionsButton.focus();
      } else if (panel === editorPanel) {
        var actionsPanel = document.getElementById('actions-panel');
        showPanel(actionsPanel);
        var saveFileButton = document.getElementById('save-file');
        if (saveFileButton) saveFileButton.focus();
      } else {
        editButton && editButton.focus();
      }
      return true;
    }
    if (document.activeElement === editorText) {
      var actionsPanel = document.getElementById('actions-panel');
      showPanel(actionsPanel);
      var saveFileButton = document.getElementById('save-file');
      if (saveFileButton) saveFileButton.focus();
      return true;
    }
    return false;
  }

  window.addEventListener('keydown', function (e) {
    var key = normalizeKey(e);
    var active = document.activeElement;
    var isTextField = active && /^(INPUT|TEXTAREA)$/.test(active.tagName);
    var mappedKey = fileListDirectionalKey(key);

    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].indexOf(key) !== -1) {
      if (active === editorText) return;
      if (active === canvas && window.KaDOS) {
        var scanCodes = { ArrowUp: 0x4800, ArrowDown: 0x5000, ArrowLeft: 0x4D00, ArrowRight: 0x4B00 };
        KaDOS.pressKey(scanCodes[key]);
        e.preventDefault();
        return;
      }
      if (moveSaveAsFocus(mappedKey)) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (isTextField && active.id === 'saveas-name' && (key === 'ArrowLeft' || key === 'ArrowRight')) return;
      moveFocus(mappedKey);
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if ((key === 'ArrowLeft' || key === 'ArrowRight') && isTextField) {
      return;
    }

    if (key === 'Enter' && active && active.id === 'save-status-ok') {
      closeSaveToast();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (key === 'Escape' || key === 'Back' || key === 'SoftRight') {
      if (closeToPreviousAction()) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
    }
    if (key === 'Backspace' && !isTextField) {
      var visible = visiblePanel();
      if (visible && visible.classList.contains('panel')) {
        if (visible.id === 'save-as-panel') {
          var saveAsActionsPanel = document.getElementById('actions-panel');
          showPanel(saveAsActionsPanel);
          document.getElementById('save-as-file').focus();
        } else if (visible === editorPanel) {
          var actionsPanel = document.getElementById('actions-panel');
          showPanel(actionsPanel);
          var saveFileButton = document.getElementById('save-file');
          if (saveFileButton) saveFileButton.focus();
        } else {
          closePanels();
          (visible === filePanel ? fileButton : actionsButton).focus();
        }
        e.preventDefault();
        e.stopPropagation();
        return;
      }
    }

    if (key === 'Enter' && filePanel && !filePanel.classList.contains('hidden') && active && active.parentNode === fileList) {
      chooseSelectedFile();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (key === 'Enter' && active && active.id === 'saveas-name') {
      saveAsEditorText();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (key === 'Enter' && active !== canvas && !isTextField && active && typeof active.click === 'function') {
      active.click();
      e.preventDefault();
      e.stopPropagation();
      return;
    }
    if (key === 'Enter' && active === canvas && window.KaDOS) {
      KaDOS.pressKey(13);
      e.preventDefault();
      return;
    }
    if (active === canvas && window.KaDOS && key && key.length === 1) {
      KaDOS.pressKey(key.toUpperCase().charCodeAt(0));
      e.preventDefault();
    }
    if (key === 'Backspace' && active === canvas && window.KaDOS) {
      KaDOS.pressKey(8);
      e.preventDefault();
    }
  }, true);

  function loadProgram(bytes, name) {
    try {
      KaDOS.loadCom(bytes);
      consoleText = '';
      mode = 'text';
      programName = name;
      loadError = '';
    } catch (e) {
      loadError = e.message;
    }
  }

  function renderFilePanel() {
    if (!fileList) return;
    fileList.innerHTML = '';
    fileItems.forEach(function (item, index) {
      var li = document.createElement('li');
      li.textContent = (item.storageName ? item.storageName + ': ' : '') + (item.path || item.name);
      li.tabIndex = 0;
      if (index === fileSelected) li.className = 'selected';
      li.addEventListener('focus', function () {
        fileSelected = index;
        Array.prototype.forEach.call(fileList.children, function (entry, entryIndex) {
          entry.classList.toggle('selected', entryIndex === index);
        });
      });
      li.addEventListener('click', function () {
        fileSelected = index;
        li.focus();
      });
      fileList.appendChild(li);
    });
    if (!fileItems.length) {
      var empty = document.createElement('li');
      empty.textContent = 'Файлы не найдены';
      fileList.appendChild(empty);
    }
  }

  function closeFilePanel() {
    if (filePanel) filePanel.classList.add('hidden');
  }

  function openFilePanel(mode) {
    fileFilterMode = mode || 'all';
    if (!window.KaLoader || !window.KaLoader.listSdFiles) {
      return;
    }
    window.KaLoader.listSdFiles().then(function (items) {
      var sourceItems = fileFilterMode === 'text' && window.KaLoader.filterTextFiles
        ? window.KaLoader.filterTextFiles(items)
        : fileFilterMode === 'supported' && window.KaLoader.filterSupportedFiles
          ? window.KaLoader.filterSupportedFiles(items)
          : items;
      fileItems = sourceItems || [];
      fileSelected = fileItems.length ? 0 : -1;
      renderFilePanel();
      if (filePanel) filePanel.classList.remove('hidden');
      if (fileItems.length && fileList.firstElementChild) {
        fileList.firstElementChild.focus();
      } else if (!fileItems.length) {
        var storages = window.KaLoader.getSdStorages();
        var names = storages.map(function (storage) { return storage.storageName || 'sdcard'; });
        loadError = fileFilterMode === 'text'
          ? 'На карте нет текстовых файлов (.txt, .cfg, .ini и др.).'
          : fileFilterMode === 'supported'
            ? 'Не найдены поддерживаемые файлы (.COM, .BIN или текстовые форматы).'
          : (names.length
            ? 'На накопителях ' + names.join(', ') + ' файлов нет.'
            : 'KaiOS не вернул SD-хранилища. Проверьте карту и разрешение device-storage:sdcard.');
      }
    }, function (error) {
      loadError = 'Не удалось прочитать SD-карту: ' + (error.message || error);
    });
  }

  function openCurrentFileItem(item) {
    if (!item) return;
    var displayName = item.name || (item.path || '').split('/').pop();
    var readTextPromise = null;
    if (item.file && typeof item.file.text === 'function') {
      readTextPromise = window.KaLoader.readTextFile(item.file);
    } else if (item.storage && item.path && typeof item.storage.get === 'function') {
      readTextPromise = window.KaLoader.readStorageTextFile(item.storage, item.path);
    } else if (item.file && item.file instanceof Blob) {
      readTextPromise = window.KaLoader.readTextFile(item.file);
    }

    if (readTextPromise) {
      readTextPromise.then(function (text) {
        setCurrentFile(item, displayName);
        editorText.value = text;
        showPanel(editorPanel);
        editorFilename.textContent = displayName;
        editorText.focus();
      }, function (error) {
        loadError = 'Не удалось прочитать текстовый файл: ' + (error.message || error);
      });
      return;
    }

    if (item.file && /\.(com|bin)$/i.test(item.name || item.path || '')) {
      try {
        window.KaLoader.validateProgramFile(item.file);
      } catch (e) {
        loadError = e.message;
        return;
      }
      window.KaLoader.readFile(item.file).then(function (bytes) {
        setCurrentFile(item, displayName);
        loadProgram(bytes, displayName);
        closePanels();
      }, function () {
        loadError = 'Не удалось прочитать файл.';
        closePanels();
      });
      return;
    }
    loadError = 'Файл нельзя открыть в редакторе.';
  }

  function chooseSelectedFile() {
    if (!fileItems.length || fileSelected < 0) {
      loadError = 'Файл не выбран.';
      return;
    }
    openCurrentFileItem(fileItems[fileSelected]);
  }

  function initializeControls() {
    var fileInput = document.getElementById('file-input');
    fileButton = null;
    editButton = document.getElementById('edit-text');
    actionsButton = document.getElementById('open-actions');
    var editorClose = document.getElementById('editor-close');
    var actionsPanel = document.getElementById('actions-panel');
    var saveAsPanel = document.getElementById('save-as-panel');
    var deletePanel = document.getElementById('delete-panel');
    var saveAsName = document.getElementById('saveas-name');
    var formatButtons = Array.prototype.slice.call(document.querySelectorAll('[data-format]'));

    function bindPointerAction(el, fn) {
      if (!el) return;
      el.addEventListener('click', function (event) {
        event.preventDefault();
        fn(event);
      });
    }

    bindPointerAction(editButton, function () {
      if (window.navigator && (typeof navigator.getDeviceStorages === 'function' || typeof navigator.getDeviceStorage === 'function')) {
        openFilePanel('supported');
      } else {
        fileInput.setAttribute('accept', '.com,.bin,.txt,.conf,.cfg,.bat,.ini,.asm,.nfo,text/plain,application/octet-stream');
        fileInput.click();
      }
    });

    bindPointerAction(fileButton, function () {
      if (window.navigator && (typeof navigator.getDeviceStorages === 'function' || typeof navigator.getDeviceStorage === 'function')) {
        openFilePanel('all');
      } else {
        fileInput.setAttribute('accept', '.com,.bin,.txt,.conf,.cfg,.bat,.ini,.asm,.nfo,text/plain,application/octet-stream');
        fileInput.click();
      }
    });

    bindPointerAction(document.getElementById('editor-save'), function () {
      saveCurrentEditor();
    });

    bindPointerAction(editorClose, function () {
      closePanels();
      editButton && editButton.focus();
    });

    function openActions() {
      showPanel(actionsPanel);
      var saveFileButton = document.getElementById('save-file');
      if (saveFileButton) saveFileButton.focus();
    }

    bindPointerAction(actionsButton, openActions);
    bindPointerAction(document.getElementById('editor-actions-open'), openActions);

    bindPointerAction(document.getElementById('save-file'), function () {
      saveCurrentEditor();
    });

    bindPointerAction(document.getElementById('create-file'), function () {
      beginSaveAs(true);
    });

    bindPointerAction(document.getElementById('save-as-file'), function () {
      beginSaveAs(false);
    });

    bindPointerAction(document.getElementById('delete-file'), beginDeleteCurrentFile);

    bindPointerAction(document.getElementById('open-file-menu'), function () {
      if (currentFile && currentFile.file) {
        openCurrentFileItem(currentFile);
        return;
      }
      openFilePanel('all');
    });

    bindPointerAction(document.getElementById('saveas-confirm'), function () {
      saveAsEditorText();
    });

    bindPointerAction(document.getElementById('save-status-ok'), function () {
      closeSaveToast();
    });

    bindPointerAction(document.getElementById('delete-confirm'), function () {
      confirmDeleteCurrentFile();
    });

    bindPointerAction(document.getElementById('delete-cancel'), function () {
      showPanel(actionsPanel);
      var fallbackButton = document.getElementById('save-file') || document.getElementById('create-file') || actionsButton;
      if (fallbackButton) fallbackButton.focus();
    });

    bindPointerAction(document.getElementById('editor-close'), function () {
      closeEditorPanel();
    });

    formatButtons.forEach(function (button) {
      bindPointerAction(button, function () {
        saveFormat = button.dataset.format;
        formatButtons.forEach(function (formatButton) {
          formatButton.classList.toggle('selected', formatButton === button);
        });
      });
    });

    fileInput.addEventListener('change', function () {
      var file = fileInput.files && fileInput.files[0];
      if (!file) return;
      var item = { name: file.name, path: file.name, file: file, storage: null };
      setCurrentFile(item, file.name);
      if (/\.(txt|conf|cfg|bat|ini|asm|nfo)$/i.test(file.name)) {
        window.KaLoader.readTextFile(file).then(function (text) {
          editorText.value = text;
          openEditorPanel(text);
        }, function (error) {
          loadError = 'Не удалось прочитать текстовый файл: ' + (error.message || error);
        });
      } else {
        try {
          window.KaLoader.validateProgramFile(file);
          window.KaLoader.readFile(file).then(function (bytes) { loadProgram(bytes, file.name); }, function () {
            loadError = 'Не удалось прочитать файл.';
          });
        } catch (error) {
          loadError = error.message;
        }
      }
      fileInput.value = '';
    });

    if (window.navigator && typeof navigator.mozSetMessageHandler === 'function') {
      function handleIncomingFileRequest(request) {
        try {
          var activity = request || {};
          var candidate = activity.source && activity.source.files && activity.source.files[0];
          if (!candidate && activity.target && activity.target.files) {
            candidate = activity.target.files[0];
          }
          if (!candidate && activity.file) {
            candidate = activity.file;
          }
          if (!candidate && activity.data && activity.data.file) {
            candidate = activity.data.file;
          }
          if (!candidate) return;
          var item = { name: candidate.name, path: candidate.name, file: candidate, storage: null };
          setCurrentFile(item, candidate.name);
          if (window.KaLoader && window.KaLoader.isTextFileName && window.KaLoader.isTextFileName(candidate.name)) {
            window.KaLoader.readTextFile(candidate).then(function (text) {
              editorText.value = text;
              openEditorPanel(text);
            }, function (error) {
              loadError = 'Не удалось открыть файл: ' + (error.message || error);
            });
            return;
          }
          window.KaLoader.validateProgramFile(candidate);
          window.KaLoader.readFile(candidate).then(function (bytes) {
            loadProgram(bytes, candidate.name);
            closePanels();
          }, function () {
            loadError = 'Не удалось открыть файл.';
          });
        } catch (error) {
          loadError = error.message || String(error);
        }
      }

      navigator.mozSetMessageHandler('activity', handleIncomingFileRequest);
      navigator.mozSetMessageHandler('open', handleIncomingFileRequest);
      navigator.mozSetMessageHandler('pick', handleIncomingFileRequest);
      navigator.mozSetMessageHandler('share', handleIncomingFileRequest);
    }

    closePanels();
    editButton.focus();
    editorText.value = window.KaLoader.loadSavedNote();
    setCurrentFile(null, window.KaLoader.DEMOS[0].name);
    loadProgram(window.KaLoader.DEMOS[0].bytes, window.KaLoader.DEMOS[0].name);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initializeControls(); loop(); });
  } else { initializeControls(); loop(); }
})();
